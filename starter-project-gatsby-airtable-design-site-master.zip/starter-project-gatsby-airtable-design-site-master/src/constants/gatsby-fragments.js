// ...GatsbyImageSharpFluid
// ...GatsbyImageSharpFixed
